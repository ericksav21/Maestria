#include <stdio.h>
#include <math.h>
#include <string.h>

#include "memo.h"
#include "matriz_vector.h"
#include "met_num.h"
#include "funciones.h"

int main(int argc, char **argv) {
	ej_4();

	return 0;
}