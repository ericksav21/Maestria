Ejercicio 2:
Se realiza el experimento de comprobar métodos de ordenamiento QSort y Shell Sort con distintos conjuntos de datos. Se van almacenando los tiempos de ejcución en dos vectores distintos y al final se calcula el promedio y la desviación estándar muestral de las mismas, las cuales sirvieron para la parte escrita de este ejercicio.

Para la visualización de los datos se realiza un QQPlot con los vectores de los tiempos para analizar si provienen de la misma distribución.

Ejercicio 5:
Se realiza el experimento computacional intensivo con un total de mil iteraciones, en las cuales se combinan los vectores dados en la descripción, se permutan y se sacan dos muestras del tamaño igual que los vectores originales, se calcula la resta absoluta de las medias y se almacena en un vector. Al finalizar se grafica la densidad de dicho vector y se calcula la p-value con la media original.

